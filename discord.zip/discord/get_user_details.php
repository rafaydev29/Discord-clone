<?php
include 'auth/config.php';

if (!isset($_GET['id'])) exit;

$user_id = (int)$_GET['id'];

$stmt = $conn->prepare("SELECT username, image, about FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($user):
?>
<div style="text-align:center;">
    <p style="font-weight:bold; font-style:italic;">user profile</p>
    <br>
    <img src="<?= $user['image'] ?: 'default.png' ?>" style="width:100px; border-radius:50%;">
    <hr>
    <br>
    <h2><?= htmlspecialchars($user['username']) ?></h2>
    <br>
    <p><?= htmlspecialchars($user['about']) ?></p>
</div>
<?php
else:
    echo "User not found.";
endif;
?>
