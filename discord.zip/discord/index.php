<?php
session_start();
include './auth/config.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username, image , about FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (isset($_POST['add_friend'])) {

    $sender_id = $user_id;
    $receiver_id = (int)$_POST['receiver_id'];

    $friendsCheck = $conn->prepare("
        SELECT id FROM friends 
        WHERE (user1_id = ? AND user2_id = ?) 
           OR (user1_id = ? AND user2_id = ?)
    ");
    $friendsCheck->bind_param("iiii", 
        $sender_id, $receiver_id, 
        $receiver_id, $sender_id
    );
    $friendsCheck->execute();
    $friendsCheck->store_result();

    if ($friendsCheck->num_rows > 0) {
        echo "<script>alert('You are already friends.'); window.location='index.php';</script>";
        exit();
    }

    $requestCheck = $conn->prepare("
        SELECT id FROM friend_requests 
        WHERE (sender_id = ? AND receiver_id = ?)
           OR (sender_id = ? AND receiver_id = ?)
    ");
    $requestCheck->bind_param("iiii",
        $sender_id, $receiver_id,
        $receiver_id, $sender_id
    );
    $requestCheck->execute();
    $requestCheck->store_result();

    if ($requestCheck->num_rows > 0) {
        echo "<script>alert('Friend request already exists.'); window.location='index.php';</script>";
        exit();
    }

    $insert = $conn->prepare("
        INSERT INTO friend_requests (sender_id, receiver_id, status)
        VALUES (?, ?, 'pending')
    ");
    $insert->bind_param("ii", $sender_id, $receiver_id);
    $insert->execute();

    echo "<script>alert('Friend request sent.'); window.location='index.php';</script>";
    exit();
}


$result = null;
if (isset($_GET['search'])) {
    $search = $_GET['search'];

    $stmt = $conn->prepare("
        SELECT id, username, image 
        FROM users 
        WHERE username LIKE ? AND id != ?
    ");
    $like = "%$search%";
    $stmt->bind_param("si", $like, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<?php include './nav.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home | Discord Style</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
     <style>
        .sidebar{
            margin-top: 10px;
            background-color: #222325;
            border: 1px solid #414348;
            height: calc(100vh - 130px);
            border-radius: 12px;
        }
     </style>
</head>
<body>
    
<div style="display: flex; ">
    <div class="sidebar">
        <?php include 'sidebar.php'; ?>
    </div>
    <div class="main-content" style="flex-grow: 1; padding: 20px;">
        <div class="container">
        
            <div class="profile">
                <div class='p1'>
                    <img src="<?= $user['image'] ?: 'default.png' ?>">
                    <h2>Welcome, <?= htmlspecialchars($user['username']) ?> 👋</h2>
                </div>
                <!-- <hr> -->
                <div class="p2">
                    <p><?= htmlspecialchars($user['about']) ?></p>
                </div>
            </div>
        
            <div class="search-box">
                <p><i class="fas fa-user-plus"></i> Find friends by username</p>
                <form method="GET" class="search-form">
                    <input type="search" name="search" placeholder="Search for friends..." required class="search-input">
                    <button type="submit">
                        <i class="fas fa-search"></i> Search
                    </button>
                </form>
            </div>
        
            <?php if ($result): ?>
                <div class="results-title">Search Results</div>
        
                <?php if ($result->num_rows == 0): ?>
                    <p style="color: var(--text-muted);">No users found.</p>
                <?php endif; ?>
        
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="user-card">
                        <img src="<?= $row['image'] ?: 'default.png' ?>">
        
                        <div class="user-info">
                            <strong><?= htmlspecialchars($row['username']) ?></strong>
                            <span>Not friends yet</span>
                        </div>
        
                        <form method="POST">
                            <input type="hidden" name="receiver_id" value="<?= $row['id'] ?>">
                            <div class="flex">

                                <button name="add_friend">
                                    <i class="fas fa-user-plus"></i> Add Friend
                                </button>
                                <button class="deny" onclick="deny()">
                                   <i class="fa-solid fa-circle-xmark"></i>
                                   <a href="./index.php">not now</a> 
                                </button>
                            </div>
                        </form>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
   <!-- <script>
    function deny(){
        window.location.href="index.php";
    } -->
   <!-- </script> -->


</body>
</html>
