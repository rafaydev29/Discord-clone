-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2026 at 07:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `discord_clone`
--

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE `blocks` (
  `id` int(11) NOT NULL,
  `blocker_id` int(11) NOT NULL,
  `blocked_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`id`, `blocker_id`, `blocked_id`, `created_at`) VALUES
(1, 17, 16, '2026-01-21 18:15:01');

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id` int(11) NOT NULL,
  `user1_id` int(11) DEFAULT NULL,
  `user2_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`id`, `user1_id`, `user2_id`, `created_at`) VALUES
(3, 18, 13, '2025-12-19 11:15:20'),
(4, 19, 13, '2025-12-20 22:10:54'),
(7, 13, 17, '2025-12-20 22:21:09'),
(11, 19, 18, '2025-12-22 08:15:50'),
(25, 18, 20, '2025-12-22 10:56:15'),
(27, 20, 16, '2025-12-22 10:57:51'),
(28, 20, 17, '2026-01-18 16:00:53'),
(29, 16, 18, '2026-01-19 18:24:37'),
(31, 17, 18, '2026-01-21 18:15:33');

-- --------------------------------------------------------

--
-- Table structure for table `friend_requests`
--

CREATE TABLE `friend_requests` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `status` enum('pending','accepted','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `friend_requests`
--

INSERT INTO `friend_requests` (`id`, `sender_id`, `receiver_id`, `status`, `created_at`) VALUES
(1, 17, 18, 'accepted', '2026-01-21 18:15:12');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(111) NOT NULL,
  `user_id` varchar(111) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `receiver_id`, `message`) VALUES
(1, '16', 0, 'hello'),
(2, '18', 0, 'ha yaar sorry'),
(3, '16', 0, 'third message'),
(4, '16', 18, 'hello bhai'),
(5, '16', 18, 'kya haal he'),
(6, '16', 11, 'ha thk he kal milenge'),
(7, '18', 16, 'ha yaar sab thk he bus tum sunao'),
(8, '18', 16, 'bus sab shi chal he'),
(9, '18', 16, 'thk he bus yaar sab shi chal he'),
(10, '18', 13, 'kesa he bhai'),
(11, '13', 18, 'ha yaar thk hoo bas tera kya hal he'),
(12, '13', 18, 'or'),
(13, '18', 16, 'ha yaar sab shi he bas'),
(14, '18', 13, 'hello bhat'),
(15, '18', 13, 'bas tum batao or'),
(16, '13', 18, 'thk bhai'),
(17, '13', 19, 'hey bro'),
(18, '13', 18, 'thk he yaar'),
(19, '16', 18, 'my name is hamza'),
(20, '18', 16, 'han mujhe pata he'),
(21, '16', 18, 'thik he bhai dekh liya aaj'),
(22, '18', 16, 'acha'),
(23, '18', 16, 'tujhe se [oocha'),
(24, '18', 17, 'hello'),
(25, '16', 20, 'hello bhai'),
(26, '18', 17, 'han bhai kya haal he'),
(27, '18', 17, 'hello'),
(28, '18', 20, 'hello'),
(29, '18', 17, 'hello kesa he bhai'),
(30, '18', 17, 'kaha he aaj kal'),
(31, '17', 20, 'hello my name is abdul rafay'),
(32, '17', 20, 'whats your name'),
(33, '17', 18, 'thk yaaar'),
(34, '16', 20, 'han bhai'),
(35, '20', 17, 'sdfsdf'),
(36, '20', 17, 'dfsdf'),
(37, '18', 20, 'hello whats your name'),
(38, '20', 16, 'sfdsd'),
(39, '18', 20, 'Hello'),
(40, '20', 18, 'sab thk tum kese ho'),
(41, '17', 20, 'Hey'),
(42, '17', 20, 'Hey'),
(43, '17', 20, 'Hey'),
(44, '18', 16, 'hello'),
(45, '17', 16, 'hello'),
(46, '17', 16, 'hello'),
(47, '17', 16, 'hello'),
(48, '17', 16, 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `about` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `image`, `about`, `password`) VALUES
(11, 'haris', 'haris@gmail.com', '', '', 'haris123'),
(16, 'hamza', 'hamza@gmail.com', 'uploads/1766061413_6943f5654fa43.jpg', 'python warrior ⚔️⚔️', 'hamza'),
(17, 'taheer', 'taheer@gmail.com', 'uploads/1766311111_6947c4c797264.jpeg', 'im a minecraft player', 'taheer'),
(18, 'rafay', 'rafay@gmail.com', 'uploads/1766311031_6947c477aa5d7.jpeg', 'coding is my passion 💯💯', 'rafay'),
(20, 'saim', 'saim@gmail.com', 'uploads/1766387289_6948ee5919a91.png', 'software developer', 'saim');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_block` (`blocker_id`,`blocked_id`),
  ADD KEY `blocked_id` (`blocked_id`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friend_requests`
--
ALTER TABLE `friend_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`,`password`),
  ADD UNIQUE KEY `username_2` (`username`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blocks`
--
ALTER TABLE `blocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `friend_requests`
--
ALTER TABLE `friend_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blocks`
--
ALTER TABLE `blocks`
  ADD CONSTRAINT `blocks_ibfk_1` FOREIGN KEY (`blocker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `blocks_ibfk_2` FOREIGN KEY (`blocked_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
