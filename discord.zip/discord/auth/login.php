<?php
include './config.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Discord Style</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../css/login.css">

    
</head>
<body>

<div class="login-wrapper">
    <div class="logo">
        <i class="fab fa-discord"></i>
    </div>

    <h2 class="login-title">Welcome back!</h2>
    <p class="login-subtitle">We're so excited to see you again</p>

    <form method="post">
        <div class="input-group">
            <label>Email</label>
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" required>
        </div>

        <div class="input-group">
            <label>Password</label>
            <i class="fas fa-lock"></i>
            <input type="password" name="password" required>
        </div>

        <button type="submit" name="btn">Log In</button>
    </form>

    <?php
    include './config.php';

    if (isset($_POST['btn'])) {

        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        if (empty($email) || empty($password)) {
            echo "<div class='message error'>Email and password are required</div>";
            exit();
        }

        $stmt = $conn->prepare("SELECT id, password FROM users WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {

            if ($password === $user['password']) {

                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];

                echo "<div class='message success'>Login successful</div>";
                echo '<script>
                    setTimeout(() => {
                        window.location.href = "../index.php";
                    }, 1000);
                </script>';

            } else {
                echo "<div class='message error'>Wrong password</div>";
            }

        } else {
            echo "<div class='message error'>User not found</div>";
            echo "<div class='signup-link'><a href='signup.php'>Create an account</a></div>";
        }
    }
    ?>
</div>

<!-- <script>
window.addEventListener('load', () => {
    const audio = new Audio('../sounds/login-sound.mp3'); 
    audio.play().catch(e => console.log("Autoplay blocked: ", e));
});
</script> -->


</body>
</html>
