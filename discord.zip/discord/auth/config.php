<?php
$conn = mysqli_connect("localhost", "root", "", "discord_clone");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
    // echo "Connected successfully";
}
?>