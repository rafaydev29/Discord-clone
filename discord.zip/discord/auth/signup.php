<?php
include './config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | Discord Style</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../css/signup.css">
</head>
<body>

<div class="signup-wrapper">
    <div class="logo">
        <i class="fab fa-discord"></i>
    </div>

    <h2 class="title">Create an account</h2>
    <p class="subtitle">Join the conversation</p>

    <form action="" method="post">
        <div class="input-group">
            <label for="username">Username</label>
            <i class="fas fa-user"></i>
            <input type="text" id="username" name="username">
        </div>

        <div class="input-group">
            <label for="email">Email</label>
            <i class="fas fa-envelope"></i>
            <input type="email" id="email" name="email">
        </div>

        <div class="input-group">
            <label for="password">Password</label>
            <i class="fas fa-lock"></i>
            <input type="password" id="password" name="password">
        </div>

        <button type="submit" name="btn">Continue</button>
    </form>

    <?php
    include './config.php';

    if (isset($_POST['btn'])) {

        $username = trim($_POST['username']);
        $email    = trim($_POST['email']);
        $password = trim($_POST['password']);

        if (empty($username) || empty($email) || empty($password)) {
            echo "<div class='message error'>All fields are required.</div>";
            exit();
        }

        $check = $conn->prepare("SELECT id FROM users WHERE email=?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            echo "<div class='message error'>User with this email already exists.</div>";
            exit();
        }

        $stmt = $conn->prepare(
            "INSERT INTO users (username, email, password) VALUES (?, ?, ?)"
        );
        $stmt->bind_param("sss", $username, $email, $password);

        if ($stmt->execute()) {
            echo "<div class='message success'>Account created successfully!</div>";
            echo '<script>
                setTimeout(() => {
                    window.location.href = "login.php";
                }, 1500);
            </script>';
        } else {
            echo "<div class='message error'>Signup failed.</div>";
        }
    }
    ?>

    <div class="login-link">
        Already have an account? <a href="login.php">Login</a>
    </div>
</div>

</body>
</html>
