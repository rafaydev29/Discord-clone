<?php
session_start();
include './config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT password, image FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (isset($_POST['delete_account'])) {

    $password = $_POST['password'];

    if ($password === $user['password']) {

        if (!empty($user['image']) && file_exists($user['image'])) {
            unlink($user['image']);
        }

        $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        $_SESSION = [];
        session_destroy();

        header("Location: ./login.php");
        exit();

    } else {
        $error = "Wrong password. Account not deleted.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Account</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <style>
        /* Basic reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #36393F; 
            color: #FFFFFF;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .delete-card {
            background-color: #2F3136; 
            padding: 30px 40px;
            border-radius: 12px;
            width: 400px;
            text-align: center;
            box-shadow: 0 8px 20px rgba(0,0,0,0.5);
        }

        .delete-card h2 {
            color: #ED4245;
            margin-bottom: 15px;
            font-size: 24px;
        }

        .delete-card p {
            margin-bottom: 20px;
            font-size: 14px;
            color: #B9BBBE;
        }

        .delete-card input[type="password"] {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: none;
            background-color: #202225;
            color: #FFFFFF;
            font-size: 14px;
        }

        .delete-card input[type="password"]::placeholder {
            color: #72767D;
        }

        .delete-card button {
            width: 100%;
            padding: 10px 0;
            background-color: #ED4245;
            color: #FFFFFF;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.2s;
            font-size: 14px;
        }

        .delete-card button:hover {
            background-color: #f14e5a;
        }

        .delete-card .cancel-link {
            display: inline-block;
            margin-top: 15px;
            color: #7289DA;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.2s;
        }

        .delete-card .cancel-link:hover {
            color: #99AAB5;
        }

        .error-message {
            color: #ED4245;
            margin-bottom: 15px;
            font-weight: bold;
            font-size: 13px;
        }
    </style>
</head>
<body>



<div class="delete-card">
    <h2><i class="fa-solid fa-triangle-exclamation"></i> Delete Account</h2>
    <p>This action is <strong>permanent</strong> and cannot be undone.</p>

    <?php if (isset($error)) echo "<div class='error-message'>$error</div>"; ?>

    <form method="post">
        <input type="password" name="password" placeholder="Enter your password" required>
        <button type="submit" name="delete_account"
            onclick="return confirm('Are you sure you want to delete your account?')">
            Delete My Account
        </button>
    </form>

    <a href="../index.php" class="cancel-link">Cancel</a>
</div>

</body>
</html>
