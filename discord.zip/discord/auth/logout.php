<?php
session_start();
session_destroy();

?>
<script>
    window.addEventListener('load', () => {
    const audio = new Audio('../sounds/lp.mp3'); 
    audio.play().catch(e => console.log("Autoplay blocked: ", e));

    window.location.href="./login.php";
});
</script>
