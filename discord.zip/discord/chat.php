<?php
session_start();
include 'auth/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$receiver_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
if (!$receiver_id) die("Invalid recipient.");

$stmt = $conn->prepare("SELECT username, image , about FROM users WHERE id=?");
if (!$stmt) die("SQL Error: " . $conn->error);
$stmt->bind_param("i", $receiver_id);
$stmt->execute();
$receiver = $stmt->get_result()->fetch_assoc();
if (!$receiver) die("User not found.");

if (isset($_POST['send'])) {

    $check = $conn->prepare("
        SELECT 1 FROM blocks 
        WHERE (blocker_id = ? AND blocked_id = ?)
           OR (blocker_id = ? AND blocked_id = ?)
    ");
    if (!$check) die("SQL Error: " . $conn->error);
    $check->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        die("You cannot message this user.");
    }

    $message = trim($_POST['message']);
    if ($message) {
        $stmt = $conn->prepare("INSERT INTO messages (user_id, receiver_id, message) VALUES (?, ?, ?)");
        if (!$stmt) die("SQL Error: " . $conn->error);
        $stmt->bind_param("iis", $user_id, $receiver_id, $message);
        $stmt->execute();
    }
    header("Location: chat.php?user_id=" . $receiver_id);
    exit();
}

if (isset($_POST['block_user'])) {
    $stmt = $conn->prepare("INSERT INTO blocks (blocker_id, blocked_id) VALUES (?, ?)");
    if (!$stmt) die("SQL Error: " . $conn->error);
    $stmt->bind_param("ii", $user_id, $receiver_id);
    $stmt->execute();

    $stmt = $conn->prepare("
        DELETE FROM friends 
        WHERE (user1_id = ? AND user2_id = ?) 
           OR (user1_id = ? AND user2_id = ?)
    ");
    if ($stmt) { 
        $stmt->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
        $stmt->execute();
    }

    $stmt = $conn->prepare("
        DELETE FROM friend_requests 
        WHERE (sender_id = ? AND receiver_id = ?) 
           OR (sender_id = ? AND receiver_id = ?)
    ");
    if ($stmt) { 
        $stmt->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
        $stmt->execute();
    }

    header("Location: ./remove_user.php");
    exit();
}

if (isset($_POST['unblock_user'])) {
    $stmt = $conn->prepare("DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?");
    if (!$stmt) die("SQL Error: " . $conn->error);
    $stmt->bind_param("ii", $user_id, $receiver_id);
    $stmt->execute();
}

$isBlocked = false;
$stmt = $conn->prepare("SELECT 1 FROM blocks WHERE blocker_id=? AND blocked_id=?");
if ($stmt) {
    $stmt->bind_param("ii", $user_id, $receiver_id);
    $stmt->execute();
    $stmt->store_result();
    $isBlocked = $stmt->num_rows > 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chat with <?= htmlspecialchars($receiver['username']) ?></title>
<link rel="stylesheet" href="css/chat.css">
<style>
.modal { display: none; position: fixed; z-index: 1000; padding-top: 100px; left:0; top:0; width:100%; height:100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; }
.modal-content { background-color: #353333; margin:20px; padding:20px; border-radius:10px; width:40%; max-width:400px; box-sizing:border-box; display:flex; flex-direction:column; gap:20px; position:relative; }
.modal-actions { display:flex; justify-content:flex-end; gap:10px; }
.modal-actions button { padding:8px 16px; border:none; border-radius:5px; cursor:pointer; font-weight:bold; }
.modal-actions .cancel { background:#777; color:white; }
.modal-actions .cancel:hover { background:#555; }
.modal-actions .confirm { background:#e11212; color:white; }
.modal-actions .confirm:hover { background:#b00d0d; }
</style>
</head>
<body>

<div class="navbar">
    <?php include 'nav.php'; ?>
</div>

<div class="container">
    <div class="sidebar" id="sidebar" role="complementary">
        <?php include 'sidebar.php'; ?>
    </div>

    <div class="main-content">

        <div class="chat-header">
            <div class="con">
                <div class="p1">
                <img src="<?= $receiver['image'] ?: 'default.png' ?>" 
                    alt="<?= htmlspecialchars($receiver['username']) ?>" 
                    class="clickable-user" 
                    data-user-id="<?= $receiver_id ?>">
                    <p title="<?= htmlspecialchars($receiver['about']) ?>">
                        <?= htmlspecialchars($receiver['username']) ?>
                    </p>
                </div>
            </div>
            <div class="p2">
                <form method="POST">
                    <button type="submit" name="<?= $isBlocked ? 'unblock_user' : 'block_user' ?>" class="block-btn bl">
                        <?= $isBlocked ? 'Unblock' : 'Remove' ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="chat-box" id="chat-box">
            <?php
            $stmt = $conn->prepare("
                SELECT m.message, u.username, u.image, m.user_id
                FROM messages m
                JOIN users u ON m.user_id = u.id
                WHERE (m.user_id=? AND m.receiver_id=?) OR (m.user_id=? AND m.receiver_id=?)
                ORDER BY m.id ASC
            ");
            if ($stmt) {
                $stmt->bind_param("iiii",$user_id,$receiver_id,$receiver_id,$user_id);
                $stmt->execute();
                $messages = $stmt->get_result();

                while($msg=$messages->fetch_assoc()):
                    $self = $msg['user_id']==$user_id ? 'self' : '';
            ?>
            <div class="message <?= $self ?>">
                <img class="avatar" 
                    src="<?= $msg['image'] ?: 'default.png' ?>" 
                    alt="<?= htmlspecialchars($msg['username']) ?>" 
                    data-user-id="<?= $msg['user_id'] ?>">
                <div><?= htmlspecialchars($msg['message']) ?></div>
            </div>
            <?php endwhile; } ?>
        </div>

        <form method="POST" class="chat-input">
            <input type="text" name="message" placeholder="Message <?= htmlspecialchars($receiver['username']) ?>" required autofocus aria-label="Message">
            <button name="send">Send</button>
        </form>

    </div>
</div>

<div id="userDetailsModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeUserModal()">&times;</span>
        <div id="userDetailsBody"></div>
    </div>
</div>

<script>
const chatBox = document.getElementById('chat-box');
chatBox.scrollTop = chatBox.scrollHeight;

document.querySelectorAll('.clickable-user').forEach(img => {
    img.addEventListener('click', () => {
        const userId = img.getAttribute('data-user-id');
        fetch('get_user_details.php?id=' + userId)
            .then(res => res.text())
            .then(data => {
                document.getElementById('userDetailsBody').innerHTML = data;
                document.getElementById('userDetailsModal').style.display = 'flex';
            });
    });
});

function closeUserModal() {
    document.getElementById('userDetailsModal').style.display = 'none';
}

window.addEventListener('click', function(e) {
    if (e.target == document.getElementById('userDetailsModal')) closeUserModal();
});
</script>

</body>
</html>
