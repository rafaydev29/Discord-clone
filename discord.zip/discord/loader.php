<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Loading...</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
body, html {
    height: 100%;
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background-color: #36393f;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    color: #fff;
}

.logo {
    font-size: 100px;
    color: #7289da; 
    animation: spin 2s linear infinite; 
    margin-bottom: 20px;
}


.loading-text {
    font-size: 1.5rem;
    font-weight: 500;
    position: relative;
}
i{
    color:blue;
}


.loading-text::after {
    content: '';
    display: idnline-block;
    width: 1em;
    text-align: left;
    animation: dots 1s steps(3, end) infinite;
}


@keyframes spin {
    0% { transform: rotate(0deg);}
    100% { transform: rotate(360deg);}
}

@keyframes dots {
    0%, 20% { content: ''; }
    40% { content: '.'; }
    60% { content: '..'; }
    80%, 100% { content: '...'; }
}
</style>
</head>
<body>

<i class="fa-brands fa-discord logo"></i>
<div class="loading-text">chat with you friends</div>

<script>

setTimeout(() => {
    window.location.href = 'index.php';
}, 3000); 

</script>

</body>
</html>
