<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<style>
.discord-nav {
    width: 100%;
    border-radius: 12px;
    background: #2b2d31;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 20px;
    margin-bottom: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    flex-shrink: 0;
    gap: 10px;
}

.discord-nav .logo {
    display: flex;
    align-items: center;
}

.discord-nav .logo i {
    color: #5865f2;
    font-size: 70px;
    margin-left: 72px;
}

.discord-nav .logo span {
    color: #fff;
    font-size: 20px;
    font-weight: 600;
}

.discord-nav .menu-toggle {
    display: none;
    background: transparent;
    border: none;
    color: #fff;
    font-size: 20px;
    cursor: pointer;
}

.discord-nav .links {
    display: flex;
    gap: 14px;
    align-items: center;
}

.discord-nav .links a {
    color: #fff;
    text-decoration: none;
    font-size: 16px;
    font-weight: 500;
    padding: 6px 10px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    border-radius: 4px;
    transition: background 0.2s;
}

.discord-nav .links a:hover {
    background: #35373c;
}

@media (max-width: 768px) {
    .discord-nav {
        flex-wrap: wrap;
        align-items: center;
    }
    .discord-nav .menu-toggle {
        display: block;
    }
    .discord-nav .links {
        display: none;
        width: 100%;
        flex-direction: column;
        gap: 6px;
        margin-top: 8px;
    }
    .discord-nav.expanded .links {
        display: flex;
    }
    .discord-nav .logo i { font-size: 36px; margin-left: 6px; }
}
</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<nav class="discord-nav" role="navigation" aria-label="Main navigation">
    <div class="logo">
        <i class="fab fa-discord" aria-hidden="true"></i>
    </div>
    <button class="menu-toggle" aria-expanded="false" aria-controls="nav-links"><i class="fas fa-bars" aria-hidden="true"></i></button>
    <div class="links" id="nav-links">
        <!-- <a href="create_server.php"><i class="fa-solid fa-square-plus" style="margin-right:10px;"></i>create server</a> -->
        <a href="#" onclick="confirmLogout()">Logout</a>
        <a href="profile.php">Profile</a>
        <a href="auth/delete_account.php">Delete Account</a>
        <a href="requests.php">Friend Requests</a>
        <a href="index.php">Home</a>
    </div>
</nav>

<script>
document.querySelector('.menu-toggle')?.addEventListener('click', function(){
    const nav = document.querySelector('.discord-nav');
    const expanded = nav.classList.toggle('expanded');
    this.setAttribute('aria-expanded', expanded);
});
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            window.location.href = "auth/logout.php";
        }else{

        }
    }
        // else: do nothing (logout cancelled)
</script>
