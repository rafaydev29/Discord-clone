<?php include 'auth/config.php' ?>
<?php
$sql = "SELECT id, username FROM users";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<ul>";
    while($row = $result->fetch_assoc()) {
        echo "<li>" . htmlspecialchars($row['username']) . "</li>";
    }
    echo "</ul>";
} else {
    echo "No users found.";
}
?>