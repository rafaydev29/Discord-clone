<?php
session_start();
include 'auth/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$receiver_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
if (!$receiver_id) die("Invalid recipient.");

$stmt = $conn->prepare("SELECT username, image , about FROM users WHERE id=?");
$stmt->bind_param("i", $receiver_id);
$stmt->execute();
$receiver = $stmt->get_result()->fetch_assoc();
if (!$receiver) die("User not found.");

if (isset($_POST['send'])) {

    $check = $conn->prepare("
    SELECT 1 FROM blocks 
    WHERE (blocker_id = ? AND blocked_id = ?)
       OR (blocker_id = ? AND blocked_id = ?)
");
$check->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    die("You cannot message this user.");
}


    $message = trim($_POST['message']);
    if ($message) {
        $stmt = $conn->prepare("INSERT INTO messages (user_id, receiver_id, message) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $user_id, $receiver_id, $message);
        $stmt->execute();
    }
    header("Location: chat.php?user_id=" . $receiver_id);
    exit();
}
?>

<?php
if (isset($_POST['block_user'])) {

    $stmt = $conn->prepare("
        DELETE FROM friends 
        WHERE (user1_id = ? AND user2_id = ?) 
           OR (user1_id = ? AND user2_id = ?)
    ");
    $stmt->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
    $stmt->execute();

    $stmt1 = $conn->prepare("
        DELETE FROM friend_requests 
        WHERE (sender_id = ? AND receiver_id = ?) 
           OR (sender_id = ? AND receiver_id = ?)
    ");
    $stmt1->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
    $stmt1->execute();

    header("Location: ./remove_user.php");
    exit();
}


if (isset($_POST['unblock_user'])) {
    $stmt = $conn->prepare("
        DELETE FROM blocks 
        WHERE blocker_id = ? AND blocked_id = ?
    ");
    $stmt->bind_param("ii", $user_id, $receiver_id);
    $stmt->execute();

    // header("Location: ./index.php");
    // exit();

    $stmt1 = $conn->prepare("delete from friend_requests WHERE blocker_id = ? AND blocked_id = ?");
    $stmt1->bind_param("ii",$user_id, $receiver_id);
    $stmt1->execute();
}


$isBlocked = false;
$stmt = $conn->prepare("SELECT 1 FROM blocks WHERE blocker_id=? AND blocked_id=?");
$stmt->bind_param("ii", $user_id, $receiver_id);
$stmt->execute();
$stmt->store_result();
$isBlocked = $stmt->num_rows > 0;


?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chat with <?= htmlspecialchars($receiver['username']) ?></title>
<link rel="stylesheet" href="css/chat.css">
</head>
<body>
    <style>
   /* Modal container */
/* Modal container */
.modal {
  display: none; 
  position: fixed; 
  z-index: 1000; 
  padding-top: 100px; 
  left: 0;
  top: 0;
  width: 100%; 
  height: 100%; 
  background-color: rgba(0,0,0,0.5); 
  justify-content: center;
  align-items: center;
}

/* Modal content */
.modal-content {
  background-color: #353333;
  margin: 20px;
  padding: 20px;
  border-radius: 10px;
  width: 40%;
  max-width: 400px;
  box-sizing: border-box;
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* Modal actions */
.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

/* Buttons inside modal */
.modal-actions button {
  padding: 8px 16px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
}

.modal-actions .cancel {
  background-color: #777;
  color: white;
}

.modal-actions .cancel:hover {
  background-color: #555;
}

.modal-actions .confirm {
  background-color: #e11212;
  color: white;
}

.modal-actions .confirm:hover {
  background-color: #b00d0d;
}

    </style>

<div class="navbar">
    <?php include 'nav.php'; ?>
</div>

<div class="container">

    <div class="sidebar" id="sidebar" role="complementary">
        <?php include 'sidebar.php'; ?>
    </div>

    <div class="main-content">

        <div class="chat-header">
            <div class="con">
                <div class="p1">
                <img src="<?= $receiver['image'] ?: 'default.png' ?>" 
                    alt="<?= htmlspecialchars($receiver['username']) ?>" 
                    class="clickable-user" 
                    data-user-id="<?= $receiver_id ?>">
                    <p title="<?php echo htmlspecialchars($receiver['about']) ?>">
                        <?php echo htmlspecialchars($receiver['username']) ?>
                    </p>
                </div>
            </div>
            <div class="p2">

               <div class="p2">
            <form method="POST">
                <button type="submit" name="block_user" class="block-btn bl">
                    Remove 
                </button>
            </form>
        </div>

            </div>

        </div>

        <div class="chat-box" id="chat-box">
            <?php
            $stmt = $conn->prepare("
                SELECT m.message, u.username, u.image, m.user_id
                FROM messages m
                JOIN users u ON m.user_id = u.id
                WHERE (m.user_id=? AND m.receiver_id=?) OR (m.user_id=? AND m.receiver_id=?)
                ORDER BY m.id ASC
            ");
            $stmt->bind_param("iiii",$user_id,$receiver_id,$receiver_id,$user_id);
            $stmt->execute();
            $messages = $stmt->get_result();

            while($msg=$messages->fetch_assoc()):
                $self = $msg['user_id']==$user_id ? 'self' : '';
            ?>
            <div class="message <?= $self ?>">
            <img class="avatar" 
                src="<?= $msg['image'] ?: 'default.png' ?>" 
                alt="<?= htmlspecialchars($msg['username']) ?>" 
                data-user-id="<?= $msg['user_id'] ?>">
                <div ><?= htmlspecialchars($msg['message']) ?></div>
            </div>
            <?php endwhile; ?>
        </div>

        <!-- <form id="blockForm" method="POST">
            <button type="button" class="cancel" onclick="closeBlockModal()">Cancel</button>
            <button type="submit" name="block_user" class="confirm">Block</button>
    
        </form> -->
        <form method="POST" class="chat-input">
    <input type="text" name="message" placeholder="Message <?= htmlspecialchars($receiver['username']) ?>" required autofocus aria-label="Message">
    <button name="send">Send</button>
</form>




    </div>
</div>






<div id="userDetailsModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeUserModal()">&times;</span>
        <div id="userDetailsBody">
        </div>
    </div>
</div>


<script>
const chatBox = document.getElementById('chat-box');
chatBox.scrollTop = chatBox.scrollHeight;

const toggleBtn = document.getElementById('toggle-sidebar');
toggleBtn?.addEventListener('click', () => {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;
    const shown = sidebar.classList.toggle('shown');
    toggleBtn.setAttribute('aria-expanded', shown);
});

document.addEventListener('click', (e) => {
    const sidebar = document.querySelector('.sidebar');
    const toggle = document.getElementById('toggle-sidebar');
    if (!sidebar || !toggle) return;
    if (sidebar.classList.contains('shown') && !sidebar.contains(e.target) && !toggle.contains(e.target)) {
        sidebar.classList.remove('shown');
        toggle.setAttribute('aria-expanded', 'false');
    }
});




function showUserDetails(userId) {
    fetch('get_user_details.php?id=' + userId)
        .then(response => response.text())
        .then(data => {
            document.getElementById('userDetailsBody').innerHTML = data;
            document.getElementById('userDetailsModal').style.display = 'flex';
        });
}

function closeUserModal() {
    document.getElementById('userDetailsModal').style.display = 'none';
}

document.querySelectorAll('.clickable-user').forEach(img => {
    img.addEventListener('click', () => {
        const userId = img.getAttribute('data-user-id');
        showUserDetails(userId);
    });
});

window.addEventListener('click', function(e) {
    const modal = document.getElementById('userDetailsModal');
    if (e.target == modal) modal.style.display = 'none';
});


function direct(){
    window.location.href="../index.php";
}
</script>

</body>
</html>
