<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include './auth/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];


$stmt = $conn->prepare("
    SELECT u.id, u.username, u.image
    FROM friends f
    JOIN users u 
      ON (u.id = f.user1_id OR u.id = f.user2_id)
    WHERE (f.user1_id=? OR f.user2_id=?) AND u.id != ?
");
$stmt->bind_param("iii", $user_id, $user_id, $user_id);
$stmt->execute();
$friends = $stmt->get_result();
?>

<link rel="stylesheet" href="css/sidebar.css">
<div class="discord-sidebar">
    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px; margin-left:15px;">
        <i class="fa-solid fa-user-group" style="margin-bottom: 10px;"></i>
        <h3>Friends</h3>
    </div>

    <?php if ($friends->num_rows === 0): ?>
        <div class="discord-empty">No friends yet</div>
    <?php endif; ?>

    <?php while ($f = $friends->fetch_assoc()): ?>
        <div class="discord-friend" title="Click to chat with <?= htmlspecialchars($f['username']) ?>">
    <img src="<?= $f['image'] ?: 'default.png' ?>">
    <span><?= htmlspecialchars($f['username']) ?></span>
    <a href="chat.php?user_id=<?= $f['id'] ?>">Chat</a>
</div>

    <?php endwhile; ?>
</div>
