<?php
session_start();
include './auth/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username, email, password, image , about FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (isset($_POST['update_profile'])) {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $about    = trim($_POST['about']); // new line

    if ($username && $email) {
        $stmt = $conn->prepare("UPDATE users SET username=?, email=?, about=? WHERE id=?");
        $stmt->bind_param("sssi", $username, $email, $about, $user_id); // updated
        $stmt->execute();
        header("Location: profile.php");
        exit();
    }
}


if (isset($_POST['update_password'])) {
    if ($_POST['old_password'] === $user['password']) {
        $new = trim($_POST['new_password']);
        if ($new) {
            $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
            $stmt->bind_param("si", $new, $user_id);
            $stmt->execute();
            header("Location: profile.php");
            exit();
        }
    } else {
        $pass_error = "Old password is incorrect";
    }
}

$showPassword = false;
if (isset($_POST['reveal_password'])) {
    if ($_POST['confirm_password'] === $user['password']) {
        $showPassword = true;
    } else {
        $reveal_error = "Wrong password";
    }
}

if (isset($_POST['upload_image']) && isset($_FILES['image'])) {
    $folder = "uploads/";
    if (!is_dir($folder)) mkdir($folder, 0755, true);

    if ($_FILES['image']['error'] === 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','webp'];

        if (in_array($ext, $allowed)) {
            $filename = time() . "_" . uniqid() . "." . $ext;
            $path = $folder . $filename;
            move_uploaded_file($_FILES['image']['tmp_name'], $path);

            $stmt = $conn->prepare("UPDATE users SET image=? WHERE id=?");
            $stmt->bind_param("si", $path, $user_id);
            $stmt->execute();

            header("Location: profile.php");
            exit();
        } else {
            $img_error = "Only JPG, PNG, WEBP allowed";
        }
    }
}
?>
<link rel="stylesheet" href="css/profile.css">
<style>
    .navbar{
        width:96%;
        margin:1%;
        /* overflow-y:; */
    }
</style>
<div class="navbar">
    <?php include 'nav.php'; ?>

</div>
<div class="profile-container">
    <h2>User Profile</h2>

    <div class="profile-layout">

        <div class="profile-left">
            <img src="<?= $user['image'] ?: 'default.png'; ?>" alt="Profile Image">

            <h3><?= htmlspecialchars($user['username']); ?></h3>
            <p><?= htmlspecialchars($user['about']); ?></p>

            <form method="post" enctype="multipart/form-data">
                <input type="file" name="image" required>
                <button name="upload_image">Upload</button>
            </form>

            <?php if (isset($img_error)) echo "<p class='error'>$img_error</p>"; ?>
        </div>

        <div class="profile-right">

            <div class="card">
                <h4>Edit Profile</h4>
                <form method="post">
                <input type="text" name="username" value="<?= htmlspecialchars($user['username']); ?>" required>
                <input type="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>
                <textarea name="about" placeholder="About yourself"><?= htmlspecialchars($user['about']); ?></textarea>
                <button name="update_profile">Save</button>
            </form>

            </div>

            <div class="card">
                <h4>Password</h4>

                <div class="password-display">
                    <?= $showPassword ? $user['password'] : '************'; ?>
                </div>

                <?php if (isset($reveal_error)) echo "<p class='error'>$reveal_error</p>"; ?>

                <form method="post">
                    <input type="password" name="confirm_password" placeholder="Confirm password">
                    <button name="reveal_password">Reveal</button>
                </form>

                <?php if (isset($pass_error)) echo "<p class='error'>$pass_error</p>"; ?>

                <form method="post">
                    <input type="password" name="old_password" placeholder="Old password">
                    <input type="password" name="new_password" placeholder="New password">
                    <button name="update_password">Change</button>
                </form>
            </div>

            <div class="link">
                <a href="logout.php">Logout</a>
                <a href="./index.php">Back</a>
            </div>

        </div>
    </div>
</div>


