<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Friend Removed</title>
<style>
body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: linear-gradient(135deg, #3280ecff, #123af0ff);
    font-family: 'Segoe UI', sans-serif;
    color: #fff;
    margin: 0;
}

.container {
    text-align: center;
    animation: fadeIn 1s ease forwards;
}

h1 {
    font-size: 3rem;
    margin-bottom: 20px;
    transform: scale(0);
    animation: pop 0.8s forwards;
}

p {
    font-size: 1.2rem;
    opacity: 0;
    animation: fadeInText 1s forwards 1s;
}

@keyframes pop {
    to { transform: scale(1); }
}

@keyframes fadeInText {
    to { opacity: 1; }
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.spinner {
    border: 6px solid rgba(255,255,255,0.2);
    border-top: 6px solid #fff;
    border-radius: 50%;
    width: 60px;
    height: 60px;
    margin: 20px auto;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg);}
    100% { transform: rotate(360deg);}
}
</style>
</head>
<body>

<div class="container">
    <h1>Friend Removed!</h1>
    <div class="spinner"></div>
    <p>Redirecting you back to home...</p>
</div>

<script>
setTimeout(() => {
    window.location.href = 'index.php';
}, 4000);
</script>

</body>
</html>
