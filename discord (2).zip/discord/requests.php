<?php
session_start();
include './auth/config.php';

$user_id = $_SESSION['user_id'];

if (isset($_POST['accept'])) {
    $request_id = $_POST['request_id'];
    $q = $conn->prepare("SELECT sender_id FROM friend_requests WHERE id=?");
    $q->bind_param("i", $request_id);
    $q->execute();
    $sender = $q->get_result()->fetch_assoc()['sender_id'];

    $add = $conn->prepare("INSERT INTO friends (user1_id, user2_id) VALUES (?, ?)");
    $add->bind_param("ii", $sender, $user_id);
    $add->execute();

    $conn->query("UPDATE friend_requests SET status='accepted' WHERE id=$request_id");
}

if (isset($_POST['reject'])) {
    $request_id = $_POST['request_id'];
    $conn->query("UPDATE friend_requests SET status='rejected' WHERE id=$request_id");
}

$stmt = $conn->prepare("
    SELECT fr.id, u.username, u.image
    FROM friend_requests fr
    JOIN users u ON fr.sender_id = u.id
    WHERE fr.receiver_id=? AND fr.status='pending'
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$requests = $stmt->get_result();
?>

<link rel="stylesheet" href="css/requests.css">

<div style="width: 96%; margin-left:1%; margin-right:2%; margin-top:2%; ">
    <?php include 'nav.php'; ?>
</div>
<div class="requests-container">
    <h2>Friend Requests</h2>

    <?php if($requests->num_rows === 0): ?>
        <p style="text-align:center; color:#b5bac1;">No pending requests</p>
    <?php endif; ?>

    <?php while($r = $requests->fetch_assoc()): ?>
        <div class="request-item">
            <div class="request-info">
                <img src="<?= $r['image'] ?: 'default.png' ?>" alt="User Image">
                <span><?= htmlspecialchars($r['username']) ?></span>
            </div>
            <div class="request-buttons">
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                    <button name="accept">Accept</button>
                    <button name="reject">Reject</button>
                </form>
            </div>
        </div>
    <?php endwhile; ?>
</div>
